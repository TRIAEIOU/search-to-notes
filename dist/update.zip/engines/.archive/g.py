import requests, re, json, time
from logging import Logger
from bs4 import BeautifulSoup
from aqt import QWebEngineView, QUrl, mw, QWebEngineView, QWebEnginePage, QThread, QObject, QWebChannel, pyqtSlot
from typing import Callable
from ..engine import *

# https://github.com/nodox/simple-tor-chrome-browser-python

#_URL = 'https://www.google.com/search?source=lnms&tbm=isch&'

# "https://www.google.com/search?q=%s&source=lnms&tbm=isch&sa=X&ved=2ahUKEwie44_AnqLpAhUhBWMBHUFGD90Q_AUoAXoECBUQAw&biw=1920&bih=947"%(search_key)
# https://www.google.com/search?q=pok&source=lnms&tbm=isch&sa=X&biw=1400&bih=1050
# https://www.google.com/url?q=https://www.jagranjosh.com/general-knowledge/history-of-pakistan-occupied-kashmir-pok-1566217614-1&amp;sa=U&amp;ved=2ahUKEwiOwImTwdSAAxWhcfEDHQUvBzIQr4kDegQIEhAC&amp;usg=AOvVaw2THloDXidQWvdiDjW56LfU
# https://www.google.com/search?q=pok&source=lnms&tbm=isch&sa=X&ved=2ahUKEwie44_AnqLpAhUhBWMBHUFGD90Q_AUoAXoECBUQAw&biw=1920&bih=947

def url(query: str):
    return (
        'https://www.google.com/search?safe=off&site=&tbm=isch&source=hp&gs_l=img'
        '&q=' + query +'&oq=' + query
    )
result: str

class Google(Engine):
    """Google search engine (BeautifulSoup) implementation"""
    @staticmethod
    def title():
        return "Google (BS)"

    def __init__(self, logger: Logger, config: dict):
        self.logger = logger

    def legend(self):
        return '"[exact term]", +/-[term], site:[url], maxn:[max results]'

    def tooltip(self):
        return \
"""<b>SEARCH ENGINE SYNTAX</b>
<ul><li>cats dogs => cats or dogs in results</li>
<li>"cats and dogs" => Exact term "cats and dogs" in results</li>
<li>cats -dogs => Fewer dogs in results</li>
<li>cats +dogs => More dogs in results</li>
<li>site:commons.wikimedia.org => Only results from commons.wikimedia.org</li>
<li>intitle:anki => Only results with webview.page() title including "anki"</li>
<li>maxn:10 => Only first 10 results (default all)</li></ul>"""

    def search(self, query: str):
        # Parse max no of matches
        maxn = 0
        if m := re.match(r'(.*?)\s*maxn:(\d+)(.*)', query):
            maxn = int(m.group(2))
            if m.group(1) and m.group(3):
                query = f'{m.group(1).strip()} {m.group(3).strip()}'
            else:
                query = m.group(1).strip() if m.group(1) else m.group(3).strip()

        def onload(*_):
            nonlocal loaded
            loaded = True
        
        def onscript(res):
            nonlocal result
            result = res or ""
        
        def sleep(seconds: int):
            start = time.time()
            while time.time() - start < seconds:
                mw.app.processEvents()

        # Setup browser
        print("Setup browser")
        webview = QWebEngineView()
        channel = QWebChannel(webview.page())
        py = Bridge(webview.page())
        channel.registerObject("py", py)
        webview.page().setWebChannel(channel)
        webview.setFixedSize(1400, 1050)

        # Load google search
        print("Load search")
        loaded = False
        connection = webview.page().loadFinished.connect(onload)
        webview.load(QUrl(url(query)))
        while not loaded:
            mw.app.processEvents()
        
        # Script webview.page() to get result
        print("Script")
        sleep(3)
        webview.page().runJavaScript(f'''await (async () => {{
            const btn = document.querySelector('form[action="https://consent.google.com/save"] button')
            if (btn) {{
                btn.click()                  
            }}
        }})();''')
        sleep(3)
        result = None
        e = webview.page().runJavaScript(f'''await (async () => {{
            const btn = document.querySelector('form[action="https://consent.google.com/save"] button')
            if (btn) {{
                btn.click()                  
            }}
            await new Promise(r => setTimeout(r, 2000))
            itms = []
            document.querySelectorAll('h3').forEach((el) => {{itms.push(el.innerText)}})
            return JSON.stringify(itms)
        }})();''',
        onscript)
        while result is None:
            mw.app.processEvents()
        print(f'e: {e}')

        # Print current page
        def onhtml(result: str):
            nonlocal html
            html = result
        html = False
        webview.page().toHtml(onhtml)
        while html is False:
            mw.app.processEvents()
        print(f"Got html: {html}")
        with open('htmllog', "w", encoding='utf-8') as fh:
            fh.write(html)
        
        # Parse results
        print(f"Parse results: {result}")
        if result:
            result = json.loads(result)
        print(f"Parsed results: {result}")
        return result or []

class Bridge(QObject):
    """Class to handle js bridge"""
    @pyqtSlot(str, result=str)
    def cmd(self, cmd):
        print(f'cmd: {cmd}')
        pass
